<?php 
include('includes/dbconnection.php');

if(isset($_POST['submit'])) {

  $student_name=$_POST['student_name'];
  $father_name=$_POST['father_name'];
  $dob=$_POST['dob'];
  $address=$_POST['address'];
  $city=$_POST['city'];
  $state=$_POST['state'];
  $pin=$_POST['pin'];
  $phone=$_POST['phone'];
  $email=$_POST['email'];
  $student_class=$_POST['student_class'];
  $marks=$_POST['marks'];
  $enrolled_date=$_POST['enrolled_date'];



$sql= "INSERT INTO student (student_name,father_name,dob,address,city,state,pin,phone,email,student_class,marks,enrolled_date) values 
  ('$student_name','$father_name','$dob','$address','$city','$state','$pin','$phone','$email','$student_class','$marks','$enrolled_date')";  

 if(mysqli_query($con,$sql))
 {
  echo '<script> alert("Data submitted");
  window.location="index.php";</script>';
 }


  else{
   
   echo "<script> alert('Data  not submitted');</script>" .$sql.  "<br>";
  }

}




?>
